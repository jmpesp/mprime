/* Common definitions in Prime95 and NTPrime */


